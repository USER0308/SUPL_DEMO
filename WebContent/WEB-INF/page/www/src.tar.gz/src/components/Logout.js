import React from 'react';
class Logout extends React.Component {


  componentDidMount(){
    var usertype = sessionStorage.getItem('usertype');
    sessionStorage.removeItem('usertype');
    sessionStorage.removeItem('username');
    sessionStorage.removeItem('token');
    if(usertype =='1'){
      window.location.href='/login/user';
    }else if(usertype =='2' || usertype =='3'){
      window.location.href='/login/bank';
    }else if(usertype =='4'){
      window.location.href='/login/mntr';
    }else{
      window.location.href='/login';
    }
  }


  render() {
    return (<div></div>);
  }
}


export default Logout;
