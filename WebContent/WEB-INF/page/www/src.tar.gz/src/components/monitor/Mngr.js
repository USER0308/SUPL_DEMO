import React from 'react';
import {browserHistory} from 'react-router';
import $ from 'jquery';
import PaginationTable from '../PaginationTable';
require('styles/App.css');


class Mngr extends React.Component {

  constructor(){
    super();
    this.state = {
			data:[],
			BKCODE: '',
      CLRBKCDE: '',			
    }
    this.handleClick=this.handleClick.bind(this);
	this.handleQuery=this.handleQuery.bind(this);
  }


handleQuery(){
		var param={BKCODE:this.state.BKCODE,CLRBKCDE:this.state.CLRBKCDE,TXNDAT:this.state.txndat};
		var _this=this;
			window.post('MonitorQuery',param,function(data){
					 var list=JSON.parse(data);
           _this.setState({
           data: list
          });
	  });
}
 handleClick(e){

	let msg = e.target.alt;
	let instrid = msg.substring(0,msg.indexOf('index'));
	let index = msg.substring(msg.indexOf('index')+5);
	let Record = this.state.data[index].Record;
	sessionStorage.setItem('INSTRID',instrid);
	sessionStorage.setItem('ACTNOFROM',Record.actnofrom);
	sessionStorage.setItem('CLRBKCDE',Record.clrbkcde);
	sessionStorage.setItem('ACTNOTO',Record.actnoto);
	sessionStorage.setItem('BKCODE',Record.bkcode);
	sessionStorage.setItem('TXAMT',Record.txamt);
	sessionStorage.setItem('CURCDE',Record.curcde);
}

handleQueryChange(e){
    const target = e.target;
    const value = target.type === 'checkbox' ? target.checked : target.value;
    const name = target.name;

    this.setState(
      {
        [name]: value
      });
}


render() {
	
    return (
    <div className='content'>
			<div className='head'>监管查询</div>
			<div className='line'></div>
			
						<div className='form-group' style={{marginLeft:'100px'}}>
								<label htmlFor='exampleInputName2'  className='querylabel'>转出银行</label>
								<input name='BKCODE'  type='text'  className='form-control'
								onChange = {e => this.handleQueryChange(e)}></input>
						</div>
						<div className='form-group' style={{marginLeft:'30px'}}>
								<label htmlFor='exampleInputName2'  className='querylabel'>转入银行</label>
								<input name='CLRBKCDE'   type='text'   className='form-control'
								onChange = {e => this.handleQueryChange(e)}></input>
						</div>
                        <div className='form-group'style={{marginLeft:'30px'}}>
								<label htmlFor='exampleInputName2'  className='querylabel'>交易日期</label>
								<input name='txndat'   type='date'   className='form-control'
								onChange = {e => this.handleQueryChange(e)}></input>
						</div>

							<button  className='btn btn-default'  style={{marginTop:'42px',marginLeft:'60px'}}
							 onClick={this.handleQuery}>查询</button>



     <PaginationTable data ={this.state.data} onClick={this.handleClick}
		  columns={['txid','bkcode','actnofrom','clrbkcde','actnoto','txamt','curcde','txndat','txntime','compst']}
      header = {['交易指示ID','转出银行号','转出账号','转入银行号','转入账号','交易金额','货币码','交易日期','交易时间','完成状态']} />
	</div>
    );
  }
}



export default Mngr;