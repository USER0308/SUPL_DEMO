import React from 'react';
import {browserHistory} from 'react-router';
import $ from 'jquery';
import PaginationTable from '../PaginationTable';
require('styles/App.css');

class BankInQuery extends React.Component {
  constructor(){
    super();
    this.state = {
			bkCode:'',
			clrbkcde:'',
			actnoTo:'',
			txndat:'',
      data:[]
		}
		this.handleQuery = this.handleQuery.bind(this);
		this.handleQueryChange = this.handleQueryChange.bind(this);
		this.handleAllQuery=this.handleAllQuery.bind(this);
  }

  componentWillMount(){
	  	var _this=this;
		  var username =sessionStorage.getItem('username');
		  var param={CLRBKCDE:username};
		window.post('BankInwardQuery',param,function(data){
          var list=JSON.parse(data);
					if(!list[0]){
						return;
          }
           _this.setState({
           data: list
          });
	  });
}		  
//       		var token=sessionStorage.getItem('token');
//      		var _this =this;
// 			$.ajax({
// 				type:'post',
// 				//功能待定
// 				url:'http://172.18.34.25:80/BankInwardQuery',
// 				data:param,
// 				async: false,
// 				beforeSend:function(xhr){
// 					xhr.setRequestHeader('Authorization', 'Bearer '+token);
// 				},
// 				success: function(data){
//          			var list=JSON.parse(data);
// 					if(!list[0]){
// 						return;
//           			}
//             _this.setState({
//             	data: list
//       		});
//         }
//       });
//   }
//查询框输入事件
handleQuery(){
			var _this=this;
			var bkCode=sessionStorage.getItem('username');
			let values = this.state;
			var param={BKCODE:values.clrbkcde,CLRBKCDE:bkCode,ACTNOTO:values.actnoTo,TXNDAT:values.txndat};
			window.post('BankInQueryCdt',param,function(data){
          var list=JSON.parse(data);
           _this.setState({
           data: list
          });
	  });
		// 	var token=sessionStorage.getItem('token');	
		// 	$.ajax({
		// 		type:'post',
		// 		url:'http://172.18.34.25:80/BankInQueryCdt',
		// 		data:JSON.stringify(param),
		// 		async: false,
		// 		beforeSend:function(xhr){
		// 			xhr.setRequestHeader('Authorization', 'Bearer '+token);
		// 		},
		// 		contentType:'application/json',
		// 		success: function(data){
		// 			var list=JSON.parse(data);
        //    _this.setState({
        //    data: list
		// 			});
		// 		}
		// 	});
}
handleAllQuery () {
			var _this=this;
			var bkCode=sessionStorage.getItem('username');
			var param={BKCODE:'',CLRBKCDE:bkCode,ACTNOTO:'',TXNDAT:''};
			window.post('BankInQueryCdt',param,function(data){
          var list=JSON.parse(data);
					if(!list[0]){
						return;
          }
           _this.setState({
           data: list
          });
	  });
			// var token=sessionStorage.getItem('token');
		
			// $.ajax({
			// 	type:'post',
			// 	url:'http://172.18.34.25:80/BankInQueryCdt',
			// 	data:JSON.stringify(param),
			// 	async: false,
			// 	beforeSend:function(xhr){
			// 		xhr.setRequestHeader('Authorization', 'Bearer '+token);
			// 	},
			// 	contentType:'application/json',
			// 	success: function(data){
			// 		var list=JSON.parse(data);
			// 			_this.setState({
			// 				data: list
			// 			});
			// 	}
			// });

}
handleClick(e){
	
	let msg = e.target.alt;
	let instrid = msg.substring(0,msg.indexOf('index'));
	let index = msg.substring(msg.indexOf('index')+5);
	let Record = this.state.data[index].Record;
	sessionStorage.setItem('INSTRID',instrid);
	sessionStorage.setItem('ACTNOFROM',Record.actnofrom);
	sessionStorage.setItem('CLRBKCDE',Record.clrbkcde);
	sessionStorage.setItem('ACTNOTO',Record.actnoto);
	sessionStorage.setItem('BKCODE',Record.bkcode);
	sessionStorage.setItem('TXAMT',Record.txamt);
	sessionStorage.setItem('CURCDE',Record.curcde);

	browserHistory.push('/bank/update/'+ instrid);
}

handleQueryChange(e){
    const target = e.target;
    const value = target.type === 'checkbox' ? target.checked : target.value;
    const name = target.name;

    this.setState(
      {
        [name]: value
      });
}

 render() {
    return (
    <div className='content'>
			<div className='head'>汇入查询</div>
			<div className='line'></div>

						<div className='form-group' style={{marginLeft:'100px'}}>
								<label  htmlFor='exampleInputName2'  className='querylabel'>账号</label>
								<input name='actnoTo'  type='text'  className='form-control'
								onChange = {e => this.handleQueryChange(e)}></input>
						</div>
						<div className='form-group'style={{marginLeft:'30px'}}>
								<label  htmlFor='exampleInputName2'  className='querylabel'>转出银行号</label>
								<input name='clrbkcde'  type='text'  className='form-control'
								onChange = {e => this.handleQueryChange(e)}></input>
						</div>
						<div className='form-group'style={{marginLeft:'30px'}}>
								<label  htmlFor='exampleInputName2'  className='querylabel'>交易日期</label>
								<input name='txndat'   type='date'   className='form-control'
								onChange = {e => this.handleQueryChange(e)}></input>
						</div>
							<button  className='btn btn-default' style={{marginTop:'42px',marginLeft:'60px'}}
							onClick={this.handleQuery}>查询</button>
							

     <PaginationTable data ={this.state.data} onClick={this.handleClick.bind(this)}
		  columns={['txid','bkcode','actnofrom','clrbkcde','actnoto','txamt','curcde','txndat']}
      header = {['交易指示ID','转出银行号','转出账号','转入银行号','转入账号','交易金额','货币码','交易日期']} />
	</div>
    );
  }
}

BankInQuery.defaultProps = {
};

export default BankInQuery;
