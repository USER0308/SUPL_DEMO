import React from 'react';
import {browserHistory} from 'react-router';
import Table from '../Table';
import $ from 'jquery';
require('styles/App.css');

class BankNostro extends React.Component {

  constructor(){
    super();
    this.state = {
      data:[]
    }
  }

  componentWillMount(){
    //this.state.data = [{'name':'zhangsan','age':15,'sex':'boy'},{'name':'lisi','age':20},{'name':'lisi','age':20}];
      var username =sessionStorage.getItem('username');
      var param={BKCODE:username};
      var _this=this;
      window.post('BankNostroQuery',param,function(data){
          var list=JSON.parse(data);
					if(!list[0]){
						return;
          }
           _this.setState({
           data: list
          });
      });
      // var token=sessionStorage.getItem('token');
      // var _this =this;

			// $.ajax({
			// 	type:'post',
			// 	//功能待定
			// 	url:'http://172.18.34.25:80/BankNostroQuery',
			// 	data:param,
			// 	async: false,
			// 	beforeSend:function(xhr){
			// 		xhr.setRequestHeader('Authorization', 'Bearer '+token);
      //   },
			// 	success: function(data){
      //     var list=JSON.parse(data);
			// 		if(!list[0]){
			// 			return;
      //     }
      //      _this.setState({
      //      data: list
      //     });
      //   }
      // });
  }

  render() {
    return (
      <div className='content'>
      <div className='head'>余额查询</div>
      <div className='line'></div>
      <Table data ={this.state.data}
      columns={['nostro_id','clrbkcde','curcde','nostro_bal']}
      header = {['银行号','清算银行号','货币码','Nostro/Vostro账户余额']}/>
    </div>
    );
  }
}



export default BankNostro;
