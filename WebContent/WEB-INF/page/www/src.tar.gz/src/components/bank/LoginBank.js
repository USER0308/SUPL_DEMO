require('normalize.css/normalize.css');
require('styles/App.css');
import React from 'react';
import {browserHistory} from 'react-router';
class LoginBank extends React.Component {

  constructor(){
    super();
    this.state = {
      password:'123456',
      username:'user_a',
      usertype:'2'
    }
  }

 handleSubmit() {
  let values =  this.state;
  let param={username:values.username,password:values.password,usertype:values.usertype};
  window.post('login',param,function(data){
    if(!data.success){
      alert(data.message);
      return;
    }
    sessionStorage.setItem('token', data.message);
    sessionStorage.setItem('usertype',values.usertype);
    sessionStorage.setItem('username',values.username);
    //browserHistory.push('bank');
    if(values.usertype =='2') {
      window.location.href='/bank';
    }else{
      window.location.href='/bank/vote';
    }
  });
}

handleChange(e){
  const value = e.target.value;
  this.setState(
    {
      usertype :value
    });
}

handleusername(e){
  this.setState(
    {
      username :e.target.value
    });
}

handlePassword(e){
  this.setState(
    {
      password :e.target.value
    });
}

  render() {
    return (
      <div>
        <h2>NOSTRO-VOSTRO Blockchain Bank Login</h2>
        <div className='login'>
          <table>
          <tbody>
          <tr>
            <th>用户名：</th>
            <td>
                <select  name='username' className='user-input' onChange={this.handleusername.bind(this)} value={this.state.username}>
                <option value ="user_a">user_a</option>
                <option value ="user_b">user_b</option>
              </select>
            </td>
          </tr>
          <tr style={{marginTop:'50px'}}>
            <th>密   &nbsp;   码：</th>
            <td>
              <input type='password' id='password' placeholder='密码'
              onChange = {e => this.handlePassword(e)} value='123456'/>
            </td>
          </tr>
          <tr>
            <td colSpan='2' style={{textAlign : 'center',marginLeft:'30px'}}>
              <button type='button' onClick ={this.handleSubmit.bind(this)} style={{marginTop:'30px'}}>登&nbsp;录</button>&nbsp;
              <button style={{marginLeft:'40px',marginTop:'30px'}}>重置</button>
            </td>
          </tr>
          </tbody>
        </table>
	    </div>
    </div>
    );
  }
}


export default LoginBank;
