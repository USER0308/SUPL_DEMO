import React from 'react';
import {browserHistory} from 'react-router';
import PaginationTable from '../PaginationTable';
require('styles/App.css');

class Vote extends React.Component {
  constructor(){
    super();
    this.state = {
      data:[]
    }
    		this.handleClick=this.handleClick.bind(this);
				this.handleQuery=this.handleQuery.bind(this);
				this.handleQueryChange=this.handleQueryChange.bind(this);
	}
			 componentWillMount(){
	//   //this.state.data = [{'name':'zhangsan','age':15,'sex':'boy'},{'name':'lisi','age':20},{'name':'lisi','age':20}];
	   	var _this=this;
				window.post('QueryVoteOpinion',function(data){
          var list=JSON.parse(data);
					if(!list[0]){
						return;
          }
           _this.setState({
           data: list
          });
	  });
}		  
handleQuery(){
			var _this=this;
			var bkCode=sessionStorage.getItem('username');

			var param={BanktoMonitor:'jianguanfang',Opinion:'C',InitiateOrganization:'BankA,BankB',RuleID:'ruleid01'};
			window.post('Creatvote',param,function(data){
          var list=JSON.parse(data);
					if(!list[0]){
						return;
          }
           _this.setState({
           data: list
          });
		});
}
handleClick(e){

	let msg = e.target.alt;
	let instrid = msg.substring(0,msg.indexOf('index'));
	let index = msg.substring(msg.indexOf('index')+5);
	let Record = this.state.data[index].Record;
	sessionStorage.setItem('INSTRID',instrid);
	sessionStorage.setItem('ACTNOFROM',Record.actnofrom);
	sessionStorage.setItem('CLRBKCDE',Record.clrbkcde);
	sessionStorage.setItem('ACTNOTO',Record.actnoto);
	sessionStorage.setItem('BKCODE',Record.bkcode);
	sessionStorage.setItem('TXAMT',Record.txamt);
	sessionStorage.setItem('CURCDE',Record.curcde);

	browserHistory.push('/bank/update/'+ instrid);
}
 handleQueryChange(e){
    const target = e.target;
    const value = target.type === 'checkbox' ? target.checked : target.value;
    const name = target.name;

    this.setState(
      {
        [name]: value
      });
} 
handleSubmit(e){
		var _this=this;
		var param={VoteId:'VoteId', Opinion:'Y', RuleId:'ruleid01'};
			window.post('Creatvote',param,function(data){
					
			});
}
 render() {
  return (
    <div className='content'>
		<div className='head'>监管投票</div>
    <div className='head_shanglian'></div>
		<div className='line'></div>
			<div className='form-inline' style={{border:'1px #535353'}}>
								<label htmlFor='exampleInputName2'  className='querylabel'>申请成为监管方</label>
							<input name='jianguanfang'   type='text'   className='form-control'
								onChange = {e => this.handleQueryChange(e)}></input>
							<button  className='btn btn-default' style={{margin:'0px 20px'}}
							 onClick={this.handleQuery}>确定</button>
		</div>
	
     <PaginationTable data ={this.state.data} onClick={this.handleClick.bind(this)}  extraColomns={[<img src='../images/disable.png' onClick={this.handleClick.bind(this)}/>]}
		  columns={['DeadlineDate', 'InitiateOrganization', 'OrganizationName','Opinion']}  RecKey='VoteId'
      header = {['截止日期','发起方','监管方','投票状态','是否接受监管']} />
		</div>
  );
  }
}


export default Vote;