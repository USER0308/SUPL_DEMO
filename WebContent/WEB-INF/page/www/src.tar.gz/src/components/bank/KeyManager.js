import React from 'react';
import PaginationTable from '../PaginationTable';
require('styles/App.css');

class KeyManager extends React.Component {
  constructor(){
    super();
    this.state = {
      data:[]
		}
  }

  componentWillMount(){
  
	}
  

 render() {
  return (
    <div className='content'>
		<div className='head'>密钥管理</div>
    <div className='head_shanglian'></div>
		<div className='line'></div>
     <PaginationTable data ={this.state.data} onClick={this.handleClick.bind(this)}
		  columns={[]}
      header = {['密钥ID','密钥成员','密钥XX','监管方','是否接受监管']} />
		</div>
  );
  }
}


export default KeyManager;