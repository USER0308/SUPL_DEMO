import React from 'react';
import {browserHistory} from 'react-router';
import $ from 'jquery';
import PaginationTable from '../PaginationTable';
require('styles/App.css');


class UserInQuery extends React.Component {
  constructor(){
		super();
    this.state = {
			actnoTo:'',
			actnoFrom:'',
			txndat:'',
			data:[]
		}
		this.handleClick=this.handleClick.bind(this);
		this.handleQuery=this.handleQuery.bind(this);
		this.handleAllQuery=this.handleAllQuery.bind(this);
  }

  componentWillMount(){
	//   //this.state.data = [{'name':'zhangsan','age':15,'sex':'boy'},{'name':'lisi','age':20},{'name':'lisi','age':20}];
			var _this=this;
	   	var username = sessionStorage.getItem('username');
			var param={ACTNOTO:username};
			window.post('UserInwardQuery',param,function(data){
          var list=JSON.parse(data);
					if(!list[0]){
						return;
          }
           _this.setState({
           data: list
          });
	  });
}		  
  //     var token=sessionStorage.getItem('token');
  //     var _this =this;
	// 		$.ajax({
	// 			type:'post',
	// 			//功能待定
	// 			url:'http://172.18.34.25:80/UserInwardQuery',
	// 			async: false,
	// 			data:param,
	// 			beforeSend:function(xhr){
	// 				xhr.setRequestHeader('Authorization', 'Bearer '+token);
	// 			},
	// 			success: function(data){

  //         var list=JSON.parse(data);
	// 				if(!list[0]){
	// 					return;
  //         }
  //          _this.setState({
  //          data: list
  //     });
  //       }
	// 		});
	
  // }

  //查询框输入事件
handleQuery () {
	var _this=this;
		var username = sessionStorage.getItem('username');
		var param={ACTNOTO:username,ACTNOFROM:this.state.actnoFrom,TXNDAT:this.state.txndat};
			window.post('UserInQueryCdt',param,function(data){
          var list=JSON.parse(data);
           _this.setState({
           data: list
          });
	  });
		// var token=sessionStorage.getItem('token');
		// var _this=this;
		// $.ajax({
	  // 	  type:'post',
		// 	  url:'http://172.18.34.25:80/UserInQueryCdt',
		// 		data:JSON.stringify(param),
		// 	  async: false,
		// 		beforeSend:function(xhr){
		// 			xhr.setRequestHeader('Authorization', 'Bearer '+token);
		// 		},
		// 		contentType:'application/json',
		// 		success: function(data){
		// 			var list=JSON.parse(data);
    //        _this.setState({
    //        data: list
		// 			});
			
		// 		}
			
		// 	});
}
handleAllQuery () {
	var _this=this;
		var username = sessionStorage.getItem('username');
		var param={ACTNOTO:username,ACTNOFROM:'',TXNDAT:''};
			window.post('UserOutInCdt',param,function(data){
          var list=JSON.parse(data);
           _this.setState({
           data: list
          });
	  });
		// var token=sessionStorage.getItem('token');
		// var _this=this;
		// $.ajax({
	  // 	  type:'post',
		// 	  url:'http://172.18.34.25:80/UserInQueryCdt',
		// 		data:JSON.stringify(param),
		// 	  async: false,
		// 		beforeSend:function(xhr){
		// 			xhr.setRequestHeader('Authorization', 'Bearer '+token);
		// 		},
		// 		contentType:'application/json',
		// 		success: function(data){
		// 			var list=JSON.parse(data);
    //        _this.setState({
    //        data: list
		// 			});
			
		// 		}
			
		// 	});
}

 handleClick(e){

	let msg = e.target.alt;
	let instrid = msg.substring(0,msg.indexOf('index'));
	let index = msg.substring(msg.indexOf('index')+5);
	let Record = this.state.data[index].Record;
	sessionStorage.setItem('INSTRID',instrid);
	sessionStorage.setItem('ACTNOFROM',Record.actnofrom);
	sessionStorage.setItem('CLRBKCDE',Record.clrbkcde);
	sessionStorage.setItem('ACTNOTO',Record.actnoto);
	sessionStorage.setItem('BKCODE',Record.bkcode);
	sessionStorage.setItem('TXAMT',Record.txamt);
	sessionStorage.setItem('CURCDE',Record.curcde);

	browserHistory.push('/bank/update/'+ instrid);
}

handleQueryChange(e){
    const target = e.target;
    const value = target.type === 'checkbox' ? target.checked : target.value;
    const name = target.name;

    this.setState(
      {
        [name]: value
      });
}

 render() {
	
    return (
    <div className='content'>		
			 <div className='form-inline'>
			<div className='head'>汇入查询</div>
							<div className='form-group' style={{marginLeft:'20px'}}>
								<label htmlFor='exampleInputName2'  className='querylabel'>转出账号</label>
								<input name='actnoFrom'  type='text'  className='form-control' 
								onChange = {e => this.handleQueryChange(e)}></input>
						</div>
						<div className='form-group'  style={{marginLeft:'20px'}}>
								<label htmlFor='exampleInputName2'  className='querylabel'>交易日期</label>
								<input name='txndat'   type='date'   className='form-control'
								onChange = {e => this.handleQueryChange(e)}></input>
						</div>

							<button  className='btn btn-default'
							 onClick={this.handleQuery}>查询</button>
							
		 </div> 
		 <div className='line'></div>
     <PaginationTable data ={this.state.data} onClick={this.handleClick}
		  columns={['txid','bkcode','actnofrom','clrbkcde','actnoto','txamt','curcde','txndat']}
      header = {['交易指示ID','转出银行号','转出账号','转入银行号','转入账号','交易金额','货币码','交易日期']} />
	</div>
    );
  }
}


export default UserInQuery;
