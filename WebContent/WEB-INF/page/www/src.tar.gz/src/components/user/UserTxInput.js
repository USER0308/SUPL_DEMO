require('normalize.css/normalize.css');
require('styles/App.css');
import {browserHistory} from 'react-router';
import React from 'react';
import $ from 'jquery';

var username = sessionStorage.getItem('username');
var bkCode = sessionStorage.getItem('bkCode');

class UserTxInput extends React.Component {

  constructor(){
		super();
    this.state = {

      clrbkCde: '',
      actnoTo: '',
      txAmt: '',
			txId:'',
			submit:false
    };

    this.handleInputChange = this.handleInputChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

 handleSubmit() {
	 if (this.state.submit==false){
	var actnoFrom =sessionStorage.getItem('username');
	var date=new Date();
	var month=date.getMonth()+1;
	var day=date.getDate();
	var monthStr;
	var dayStr;
	var post=1;
	if(month<10){
		monthStr='0'+month;
	}else {
		monthStr=''+month;
	}
	if(day<10){
		dayStr='0'+day;
	}else{
		dayStr=''+day;
	}	
	if(this.state.clrbkCde==''||this.state.txAmt==''||this.state.actnoTO==''||this.state.curCde==''){
		alert("您输入的数据有空值，请重新填写");
		post=0;
	}

	else if(this.state.clrbkCde==bkCode){
		alert("转入银行号输入错误");
		post=0;
	}
	 else if(this.state.txAmt<=0){
		alert("输入金额需大于0");
		post=0;
	}
	var day=''+date.getFullYear()+'-'+monthStr+'-'+dayStr;
	var time=''+date.getHours()+':'+date.getMinutes()+':'+date.getSeconds();
	//INSTRID:txId,
	var param={BKCODE:bkCode,ACTNOFROM:actnoFrom,CLRBKCDE:this.state.clrbkCde,
							ACTNOTO:this.state.actnoTo,TXAMT:this.state.txAmt,CURCDE:this.state.curCde,
							TXNDAT:day,TXNTIME:time};
   
	if(post==1){
    window.post('UserTxInput',param,function(data){
   	if(data=='success'){
		    // window.location.href='../page/index3.html';
		    window.location.href='../page/index3.html';
			 //window.location.href='/user/outquery'; 
			 this.setState({
			submit:true
 	       });
 			}else{
				 alert('failed.');
 			}
 		});	
 	
	} 
}  
}
// 	var token=sessionStorage.getItem('token');
// 	$.ajax({
// 		type:'post',
// 		url:'http://172.18.34.25:80/UserTxInput',
// 		data:JSON.stringify(param),
// 		async: false,
// 		beforeSend:function(xhr){
// 			xhr.setRequestHeader('Authorization', 'Bearer '+token);
// 		},
// 		contentType:'application/json',
// 		success: function(data){
// 			alert(data);
// 			if(data=='success'){
// 				window.location.href='/user/outquery';
// 			}else{
// 				alert('failed.');
// 			}
// 		}
// 	});
// 	 this.setState({
// 			submit:true
// 	  });
// 	 }
// }

handleInputChange(e){
    const target = e.target;
    const value = target.type === 'checkbox' ? target.checked : target.value;
    const name = target.name;

    this.setState(
      {
        [name]: value
      });
}



  render() {
    return (
    <div className='content'>
		<div className='head'>交易录入</div>
		<div className='line'></div>
		<table id='tab'>
			<tbody>
			<tr className='tabtr'>
				<td>
					<div className='tb-title' style={{marginLeft: '70px'}}>转出银行号</div> <input value={bkCode} 
					type='text' name='bkCode' className='user-input' disabled />
				</td>
				<td>
					<div className='tb-title' style={{marginLeft: '70px'}}>转出账号</div> <input
					type='text' name='actnoFrom'  className='user-input' value={username}   disabled/>
				</td>
			</tr>
				<tr className='tabtr'>
				<td>
					<div className='tb-title' style={{marginLeft: '70px'}}>转入银行号</div> <input
					type='text'id="clrbkCde" name='clrbkCde' className='user-input' onChange={this.handleInputChange} />
				</td>
				<td>
					<div className='tb-title' style={{marginLeft: '70px'}}>转入账号</div> <input
					type='text' name='actnoTo' className='user-input' onChange={this.handleInputChange} />
				</td>
			</tr>
			<tr className='tabtr'>
				<td>
					<div className='tb-title' style={{marginLeft: '70px'}}>交 易 金 额 </div>
					 <input type='number' id="txAmt "name='txAmt' className='user-input' onChange={this.handleInputChange}/>
				</td>
				<td>
					<div className='tb-title' style={{marginLeft: '70px'}}>货    币    码  </div> 
					<select  name='curCde' className='user-input' onChange={this.handleInputChange} style={{marginLeft: '16px'}}>
						<option value ="">--请选择币别--</option>
						<option value ="HKD">HKD</option>
						<option value ="USD">USD</option>
						<option value="CNY">CNY</option>
						<option value="EUR">EUR</option>
					</select>
				</td>
			</tr>
			</tbody>
		</table>
		<div className='submitbt'>
			<button className='button' onClick={this.handleSubmit}>提&nbsp;&nbsp;交</button>
		</div>
	</div>
    );
  }
}


export default UserTxInput;
