require('normalize.css/normalize.css');
require('styles/App.css');
import React from 'react';
import {browserHistory} from 'react-router';
class LoginUser extends React.Component {

  constructor(){
    super();
    this.state = {
      password:'123456',
      username:'wangbin'
    }
  }

 handleSubmit() {
  let values =  this.state;
  let param={username:values.username,password:values.password,usertype:'1'};
  window.post('login',param,function(data){
    if(!data.success){
      alert(data.message);
      return;
    }
    sessionStorage.setItem('token', data.message);
    sessionStorage.setItem('usertype','1');
    sessionStorage.setItem('bkCode',data.bank);
    sessionStorage.setItem('username',values.username);
    //go to user page
    //browserHistory.push('user');
    window.location.href='/user';
  });
}

handleChange(e){
  this.setState(
    {
      usertype :e.target.value
    });
}

handleusername(e){
  this.setState(
    {
      username :e.target.value
    });
}

handlePassword(e){
  this.setState(
    {
      password :e.target.value
    });
}


handleInputChange(e){
  const target = e.target;
  const value = target.type === 'checkbox' ? target.checked : target.value;
  const name = target.name;
  alert(name);
  this.setState(
    {
      [name]: value
    });
}

  render() {
    return (
      <div>
        <h2>NOSTRO-VOSTRO Blockchain User Login</h2>
        <div className='login'>
          <table>
          <tbody>
          <tr>
            <th>用户名：</th>
            <td>
                <select  name='username' className='user-input' onChange={this.handleusername.bind(this)} value={this.state.username}>
                <option value ="wangbin">wangbin</option>
                <option value ="sufan">sufan</option>
              </select>
            </td>
          </tr>
          <tr style={{marginTop:'50px'}}>
            <th>密   &nbsp;   码：</th>
            <td>
              <input type='password' id='password' placeholder='密码'
              onChange = {e => this.handlePassword(e)} value='123456'/>
            </td>
          </tr>
          <tr>
            <td colSpan='2' style={{textAlign : 'center',marginLeft:'30px'}}>
              <button type='button' onClick ={this.handleSubmit.bind(this)} style={{marginTop:'30px'}}>登&nbsp;录</button>&nbsp;
              <button style={{marginLeft:'40px',marginTop:'30px'}}>重置</button>
            </td>
          </tr>
          </tbody>
        </table>
	    </div>
    </div>
    );
  }
}


export default LoginUser;
