import React from 'react';
import ReactDOM from 'react-dom';
import { Link } from 'react-router';
import bank from './../images/bank.png';
import user from './../images/user.png';

class Header extends React.Component {
  
  render() {
       
return (
    <div>
      <nav className='navbar navbar-inverse 'style={{margin:'0 auto'}}>
            <div className='container'>
              <div className='navbar-header'>
                {this.props.usertype == '2' ? 	<img src={bank} className='imageicon' /> : 	<img src={user} className='imageicon' />}
                <span className='navbar-brand'>{this.props.usertype == '2' ? '银行号：' : '账号'}</span>
                <span className='navbar-brand'>{this.props.username}</span>
              </div>
              <div id='navbar' className='navbar-collapse collapse' style={{marginTop:'15px'}}>
                <ul className='nav navbar-nav navbar-right' >
                  {(() => {switch (this.props.usertype) {
                       case '1':
                       return <div>
                       <Link to='/user/input' className='headNav'>交易录入</Link>&nbsp;
                       <Link to='/user/inquery' className='headNav'>汇入查询</Link>&nbsp;
                       <Link to='/user/outquery' className='headNav'>汇出查询</Link>
                       <Link to='/logout' className='headNav'>注销</Link>
                    </div>

                      case '2':
                        return <div>
                      <Link to='/bank/inquery' className='headNav'><font style={{hoverColor:'#fff'}}>汇入查询</font></Link>&nbsp;
                      <Link to='/bank/outquery'className='headNav' >汇出查询</Link>&nbsp;
                      <Link to='/bank/nostro' className='headNav'>NOSTRO查询</Link>
                      <a href='../page/BankShowChain.html'  className='headNav'>区块浏览</a>
                      <Link to='/logout' className='headNav'>注销</Link>
                    </div>
                    
                      case '3':
                         return <div>
                       <Link to='/bank/regulate' className='headNav'>发起监管</Link>&nbsp;
                       <Link to='/bank/vote' className='headNav'>监管投票</Link>
                       <Link to='/logout' className='headNav'>注销</Link></div>
                      
                      case '4':
                         return <div>
                      {/* <Link to='/monitor/regulate' className='headNav' >发起监管</Link>&nbsp; */}
                      <Link to='/monitor/query' className='headNav'>监管查询</Link>&nbsp;
                      <Link to='/logout' className='headNav' >注销</Link></div>
                    }})()}

                   {/* {this.props.usertype == '2' ?
                    <div>
                      <Link to='/bank/inquery' className='headNav'><font style={{hoverColor:'#fff'}}>汇入查询</font></Link>&nbsp;
                      <Link to='/bank/outquery'className='headNav' >汇出查询</Link>&nbsp;
                      <Link to='/bank/nostro' className='headNav'>NOSTRO查询</Link>
                       <Link to='/bank/nostro' className='headNav'>密钥管理</Link>&nbsp;
                       <Link>监管投票</Link>
                      <a href='../page/BankShowChain.html'  className='headNav'>区块浏览</a>
                      <Link to='/logout' className='headNav'>注销</Link>
                    </div>
                  :
                  <div>
                      <Link to='/user/input' className='headNav'>交易录入</Link>&nbsp;
                      <Link to='/user/inquery' className='headNav'>汇入查询</Link>&nbsp;
                      <Link to='/user/outquery' className='headNav'>汇出查询</Link>
                      <Link to='/logout' className='headNav'>注销</Link>
                  </div>
                } */}
                </ul>
              </div>
            </div>
          </nav>
    </div>
    );
  }
}

export default Header;
