import React from 'react';
import {browserHistory} from 'react-router';
import $ from 'jquery';
require('styles/App.css');


class Admin extends React.Component {

  constructor(){
    super();
    this.state = {
      data:[]
    }
  }


   render() {
	
    return (
    <div className='content'>
			<div className='head'>发起监管</div>
			<div className='line'></div>
            <table>
               	<tbody>
			<tr>
				<td>
					<div className='tb-title' style={{marginLeft: '70px'}}>监管方名称</div> <input
					type='text' name='bkCode' className='user-input' onChange={this.handleInputChange} />
				</td>
			</tr>
				<tr className='tabtr'> 
                    <td>	
                        <div className='tb-title' style={{marginLeft: '70px'}}>监管银行</div>
                    </td>
                </tr>
             <tr className='tabtr'>
				<td>
					<div className='tb-title' style={{marginLeft: '70px'}}>CNCB</div> <input
					type='checkbox' name='clrbkCde' className='user-input' onChange={this.handleInputChange}/>
				</td>
				<td>
					<div className='tb-title' style={{marginLeft: '70px'}}>CNCBI</div> <input
					type='checkbox' name='actnoTo' className='user-input' onChange={this.handleInputChange}/>
				</td>
			</tr>
			<tr className='tabtr'>
				<td>
					<div className='tb-title' style={{marginLeft: '84px'}}>A</div> <input
					type='checkbox' name='txAmt' className='user-input' onChange={this.handleInputChange}/>
				</td>
				<td>
					<div className='tb-title' style={{marginLeft: '88px'}}>B</div> <input
					type='checkbox' name='curCde' className='user-input' onChange={this.handleInputChange}/>
				</td>
			</tr>
			</tbody>
            </table>
            <div className='submitbt'>
			<button className='button' onClick={this.handleSubmit}>提&nbsp;&nbsp;交</button>
		</div>
	</div>
    );
  }
}



export default Admin;