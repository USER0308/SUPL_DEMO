require('normalize.css/normalize.css');
require('styles/App.css');
import React from 'react';
import {browserHistory} from 'react-router';
class LoginUser extends React.Component {

  constructor(){
    super();
    this.state = {
      data:[]
    }
  }

 handleSubmit() {
  let values =  this.state;
  let param={username:values.username,password:values.password,usertype:values.usertype};
  window.post('login',param,function(data){
    if(!data.success || !data.bank){
      alert('用户名或密码错误');
      return;
    }
    sessionStorage.setItem('token', data.message);
    sessionStorage.setItem('usertype',values.usertype);
    sessionStorage.setItem('username',values.username);
    //go to user page
    browserHistory.push('administor');
    
  });
}

handleChange(e){
  this.setState(
    {
      usertype :e.target.value
    });
}

handleusername(e){
  this.setState(
    {
      username :e.target.value
    });
}

handlePassword(e){
  this.setState(
    {
      password :e.target.value
    });
}

  render() {
    return (
      <div>
        <h2>NOSTRO-VOSTRO Blockchain Administor Login</h2>
        <div className='login'>
          <table>
          <tbody>
          <tr>
            <th>用户名：</th>
            <td>
              <input type='text' id='username' placeholder='账户/银行号'
                onChange = {e => this.handleusername(e)}/>
            </td>
          </tr>
          <tr>
            <th>密&nbsp;码：</th>
            <td>
              <input type='password' id='password' placeholder='密码'
              onChange = {e => this.handlePassword(e)}/>
            </td>
          </tr>
          <tr>
            <td colSpan='2' style={{textAlign : 'center',marginLeft:'20px'}}>
              <button type='button' onClick ={this.handleSubmit.bind(this)}>登&nbsp;录</button>&nbsp;
              <button style={{marginLeft:'40px'}}>重置</button>
            </td>
          </tr>
          </tbody>
        </table>
	    </div>
    </div>
    );
  }
}


export default LoginUser;
