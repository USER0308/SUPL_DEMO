import React from 'react';
import {browserHistory} from 'react-router';
import PaginationTable from '../PaginationTable';
require('styles/App.css');

class Vote extends React.Component {
  constructor(){
    super();
    this.state = {
      data:[]
    }
    		this.handleClick=this.handleClick.bind(this);

  }

handleClick(e){

	let msg = e.target.alt;
	let instrid = msg.substring(0,msg.indexOf('index'));
	let index = msg.substring(msg.indexOf('index')+5);
	let Record = this.state.data[index].Record;
	sessionStorage.setItem('INSTRID',instrid);
	sessionStorage.setItem('ACTNOFROM',Record.actnofrom);
	sessionStorage.setItem('CLRBKCDE',Record.clrbkcde);
	sessionStorage.setItem('ACTNOTO',Record.actnoto);
	sessionStorage.setItem('BKCODE',Record.bkcode);
	sessionStorage.setItem('TXAMT',Record.txamt);
	sessionStorage.setItem('CURCDE',Record.curcde);

	browserHistory.push('/bank/update/'+ instrid);
}
  

 render() {
  return (
    <div className='content'>
		<div className='head'>监管投票</div>
    <div className='head_shanglian'></div>
		<div className='line'></div>
     <PaginationTable data ={this.state.data} onClick={this.handleClick.bind(this)}
		  columns={[<a type="radiobutton"/>,<button/>]}  
      header = {['监管ID','监管方','发起者','是否接受监管','提交']} />
		</div>
  );
  }
}


export default Vote;