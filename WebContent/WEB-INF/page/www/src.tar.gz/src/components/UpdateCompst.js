import React from 'react';
class UpdateCompst extends React.Component {

  constructor(){
    super();
    this.state={
      INSTRID: sessionStorage.getItem('INSTRID'),
      COMPST: sessionStorage.getItem('COMPST'),
      BKCODE: sessionStorage.getItem('BKCODE'),
      ACTNOFROM: sessionStorage.getItem('ACTNOFROM'),
      CLRBKCDE: sessionStorage.getItem('CLRBKCDE'),
      ACTNOTO: sessionStorage.getItem('ACTNOTO'),
      TXAMT: sessionStorage.getItem('TXAMT'),
      CURCDE: sessionStorage.getItem('CURCDE')
    }
  }

  componentDidMount(){

  }


  render() {
    return (
    <div className='content'>
		<div className='head'>修改交易状态</div>
		<div className='line'></div>
		<table>
			<tbody>
			<tr>
				<td>
					<div className='tb-title' style={{marginLeft:90}}>交易指示ID</div>
					<span className='select' id='INSTRID'>{this.state.INSTRID}</span>
				</td>
				<td >
					<div className='tb-title'  style={{marginLeft:17}} id='COMPST'>交易状态</div>
					<select className='updateStatus'>
						<option value='P'>等待</option>
						<option value='S'>成功</option>
						<option value='R'>拒纳</option>
					</select>
				</td>
			</tr>
			<tr>
				<td>
					<div className='tb-title' style={{marginLeft:90}}>转出银行号</div>
					<span className='select' id='BKCODE'>{this.state.BKCODE}</span>
				</td>
				<td >
					<div className='tb-title' style={{marginLeft:17}}>转出账号</div>
					<span className='select' id='ACTNOFROM'>{this.state.ACTNOFROM}</span>
				</td>
			</tr>
			<tr>
				<td>
					<div className='tb-title' style={{marginLeft:90}}>转入银行号</div>
					<span className='select' id='CLRBKCDE'>{this.state.CLRBKCDE}</span>
				</td>
				<td>
					<div className='tb-title' style={{marginLeft:17}}>转入账号</div>
					<span className='select' id='ACTNOTO'>{this.state.ACTNOTO}</span>
				</td>
			</tr>
			<tr>
				<td>
					<div className='tb-title' style={{marginLeft:107}}>交易金额</div>
					<span className='select' id='TXAMT'>{this.state.TXAMT}</span>
				</td>
				<td>
					<div className='tb-title' style={{marginLeft:34}}>货币码</div>
					<span className='select' id='CURCDE'>{this.state.CURCDE}</span>
				</td>
			</tr>
			</tbody>
		</table>
		<div className='bt'>
			<button className='button' onClick={this.handleSubmit}>确&nbsp;&nbsp;定</button>
		</div>
	</div>);
  }
}


export default UpdateCompst;
