require('normalize.css/normalize.css');
require('styles/App.css');

import React from 'react';
import Header  from 'components/Header';

class Main extends React.Component {

  render() {
    return (
      <div >
        <Header usertype = {this.props.usertype} username= {this.props.username}/>
         {this.props.children}
      </div>
    );
  }
}


Main.defaultProps = {
   usertype :sessionStorage.getItem('usertype'),
   username :sessionStorage.getItem('username')
};

export default Main;
