import 'core-js/fn/object/assign';
import React from 'react';
import ReactDOM from 'react-dom';
import App from './components/Main';
import { Router, IndexRoute, Route, browserHistory} from 'react-router';
import LoginUser from './components/user/LoginUser';
import LoginBank from './components/bank/LoginBank';
import LoginMngr from './components/monitor/LoginMngr';
import Logout from './components/Logout';
import BankInQuery from './components/bank/BankInwardQuery';
import BankOutQuery from './components/bank/BankOutwardQuery';
import BankNostro from './components/bank/BankNostro';
import KeyManager from './components/bank/KeyManager';
import BankRegulate from './components/bank/BankRegulate.js';
import UserTxInput from './components/user/UserTxInput';
import UserInQuery from './components/user/UserInwardQuery';
import UserOutQuery from './components/user/UserOutwardQuery';
import Mngr from './components/monitor/Mngr';
import MngrRegulate from './components/monitor/MngrRegulate.js';
import vote from './components/bank/Vote';
// Render the main component into the dom

ReactDOM.render((
  <Router history={browserHistory}>
     <Route path="login" >
       <IndexRoute component={LoginUser}/>
        <Route path="/login/user" component={LoginUser} />
        <Route path="/login/bank" component={LoginBank} />
        <Route path="/login/mntr" component={LoginMngr} />
     </Route>
    <Route path="/logout" component={Logout} />
    <Route path="user" component={App}>
        <IndexRoute component={UserTxInput}/>
        <Route path="input" component={UserTxInput}></Route>
        <Route path="inquery" component={UserInQuery}></Route>
        <Route path="outquery" component={UserOutQuery}></Route>
    </Route>
    <Route path="bank" component={App}>
        <IndexRoute component={BankNostro}/>
        <Route path="inquery" component={BankInQuery}></Route>
        <Route path="outquery" component={BankOutQuery}></Route>
        <Route path="nostro" component={BankNostro}></Route>
        
        <Route path="regulate" component={BankRegulate}></Route>
        <Route path="vote" component={vote}></Route>
    </Route>
      <Route path="monitor" component={App}>
        <IndexRoute component={Mngr}/>
        <Route path="query" component={Mngr}></Route>
        <Route path="regulate" component={MngrRegulate}></Route>
    </Route>
  </Router>
), document.getElementById('app'))
